package cp213;

//id: 210960430

/**
 * @author Ruveyda Nur Kizmaz
 * @version 2023-02-03
 */
public class Palindrome {
	// Constants
	public static final String VOWELS = "aeiouAEIOU";

	/**
	 * Determines if string is a "palindrome": a word, verse, or sentence (such as
	 * "Able was I ere I saw Elba") that reads the same backward or forward. Ignores
	 * case, spaces, digits, and punctuation in the string parameter s.
	 *
	 * @param string a string
	 * @return true if string is a palindrome, false otherwise
	 */
	public static boolean isPalindrome(final String string) {

		int length = string.length();
		String palindrome = "";
		boolean result = true;

		for (int i = length - 1; i >= 0; i--) {

			if (Character.isLetter(string.charAt(i)) == true) {

				palindrome += Character.toLowerCase(string.charAt(i));
			} else {
				palindrome += "";
			}

		}

		System.out.println("hmm");
		System.out.println(palindrome);

		for (int j = palindrome.length() - 1, k = 0; j >= 0; j--, k++) {

			if (palindrome.charAt(k) != palindrome.charAt(j)) {
				result = false;
			}
		}

		return result;
	}
	


	/**
	 * Converts a word to Pig Latin. The conversion is:
	 * <ul>
	 * <li>if a word begins with a vowel, add "way" to the end of the word.</li>
	 * <li>if the word begins with consonants, move the leading consonants to the
	 * end of the word and add "ay" to the end of that. "y" is treated as a
	 * consonant if it is the first character in the word, and as a vowel for
	 * anywhere else in the word.</li>
	 * </ul>
	 * Preserve the case of the word - i.e. if the first character of word is
	 * upper-case, then the new first character should also be upper case.
	 *
	 * @param word The string to convert to Pig Latin
	 * @return the Pig Latin version of word
	 */
	public static String pigLatin(String word) {

		// your code here

		return null;
	}

}
