package cp213;

//id: 210960430

/**
 * @author Ruveyda Nur Kizmaz
 * @version 2023-02-03
 */
public class Encipher {
	// Constants
	public static final String ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	public static final int ALPHA_LENGTH = ALPHA.length();

	/**
	 * Encipher a string using a shift cipher. Each letter is replaced by a letter
	 * 'n' letters to the right of the original. Thus for example, all shift values
	 * evenly divisible by 26 (the length of the English alphabet) replace a letter
	 * with itself. Non-letters are left unchanged.
	 *
	 * @param s string to encipher
	 * @param n the number of letters to shift
	 * @return the enciphered string in all upper-case
	 */
	public static String shift(final String s, final int n) {

		int pn;
		String text = "";

		pn = n % ALPHA_LENGTH; // to start from beginning again

		// loop through s

		for (int i = 0; i < s.length(); i++) {

			if (Character.isLetter(s.charAt(i)) == true) {

				int indexLetter = ALPHA.indexOf(s.charAt(i)); // get index of char in ALPHA

				/*
				 * you dont have to convert char to str
				 */
				// char newChar = ALPHA.charAt(indexLetter + pn);
				// text += Character.toString(newChar);

				// char newChar = ALPHA.charAt((indexLetter + pn) % ALPHA_LENGTH);

				text += ALPHA.charAt((indexLetter + pn) % ALPHA_LENGTH);

			} else {
				text += s.charAt(i);
			}

		}

		return text;
	}

	/**
	 * Encipher a string using the letter positions in ciphertext. Each letter is
	 * replaced by the letter in the same ordinal position in the ciphertext.
	 * Non-letters are left unchanged. Ex:
	 *
	 * <pre>
	Alphabet:   ABCDEFGHIJKLMNOPQRSTUVWXYZ
	Ciphertext: AVIBROWNZCEFGHJKLMPQSTUXYD
	 * </pre>
	 *
	 * A is replaced by A, B by V, C by I, D by B, E by R, and so on. Non-letters
	 * are ignored.
	 *
	 * @param s          string to encipher
	 * @param ciphertext ciphertext alphabet
	 * @return the enciphered string in all upper-case
	 */
	public static String substitute(final String s, final String ciphertext) {

		String ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String CIPHER = "AVIBROWNZCEFGHJKLMPQSTUXYD";
		String message = "";

		for (int i = 0; i < s.length(); i++) {

			if (Character.isLetter(s.charAt(i)) == true) {

				int indexLetter = ALPHABET.indexOf(s.charAt(i)); // get index from ALPHABET
				message += CIPHER.charAt(indexLetter); // add the cipher indexed value

			} else {
				message += ""; // non characters skipped
			}

		}

		return message;
	}

}
